﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;
namespace FarmAdvisor.Business
{
    
    public class WeatherForecastApi
    {
        private readonly HttpClient _httpCLient = new HttpClient();
    
        public async Task<Weather?> GetLocationForecast(double latitude, double longitude, double altitude)
        {
            _httpCLient.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36");
            Weather? response;
            try
            {
            response =  await _httpCLient.GetFromJsonAsync<Weather>($"https://api.met.no/weatherapi/locationforecast/2.0/complete?lat={latitude.ToString()}&lon={longitude.ToString()}&altitude={altitude.ToString()}");
            }
            catch(Exception ex)
            {
                response = null;
            }
            return response;
        }

        
    }
}
