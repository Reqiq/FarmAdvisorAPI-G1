﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmAdvisor.Business
{
    public class Field
    {
        public Guid FieldId { get; set; }
        public string Name { get; set; } = string.Empty;
        public int Alt { get; set; }
        public string Polygon { get; set; }

        public Field(Guid fieldId, string name, int alt, string polygon)
        {
            FieldId = fieldId;
            Name = name;
            Alt = alt;
            Polygon = polygon;
        }
    }

    public class Sensor
    {
        public Guid SensorId { get; set; }
        public string SerialNumber { get; set; }
        public DateTime LastCommunication { get; set; }

        public int BatteryStatus { get; set; }
        public int OptimalGDD { get; set; }
        public DateTime? CuttingDateTimeCalculated { get; set; }

        public DateTime? LastForecastDate { get; set; }

        public double Lat { get; set; }
        public double Long { get; set; }



        public virtual Field Field { get; set; }
        public Sensor(Guid sensorId, string serialNumber, DateTime lastCommunication, int batteryStatus, int optimalGDD, DateTime? cuttingDateTimeCalculated, DateTime? lastForecastDate, double lat, double @long, Field field)
        {
            SensorId = sensorId;
            SerialNumber = serialNumber;
            LastCommunication = lastCommunication;
            BatteryStatus = batteryStatus;
            OptimalGDD = optimalGDD;
            CuttingDateTimeCalculated = cuttingDateTimeCalculated;
            LastForecastDate = lastForecastDate;
            Lat = lat;
            Long = @long;
            Field = field;
        }
    }

    public class SensorImitation
    {

        public static List<Sensor> GetActiveSensors()
        {
            Field field1 = new Field(Guid.NewGuid(), "field 1", 4150, "polygon 1");
            Field field2 = new Field(Guid.NewGuid(), "field 2", 3101, "polygon 2");

            List<Sensor> sensorList = new List<Sensor>();
            sensorList.Add(new Sensor(
                    Guid.NewGuid(),
                    "AER12891829",
                    DateTime.Now.AddDays(-1),
                    1,
                    100,
                    DateTime.Now.AddDays(7),
                    DateTime.Now.AddDays(9),
                    -16.516667,
                    -68.166667,
                    field1
                ));
            sensorList.Add(new Sensor(
                    Guid.NewGuid(),
                    "ADR12823129",
                    DateTime.Now.AddDays(-2),
                    1,
                    85,
                    DateTime.Now.AddDays(17),
                    DateTime.Now.AddDays(8),
                    35.121,
                    12.121,
                    field1));
            sensorList.Add(new Sensor(
                     Guid.NewGuid(),
                     "BPF1589182",
                     DateTime.Now.AddDays(-4),
                     1,
                     81,
                     DateTime.Now.AddDays(17),
                     DateTime.Now.AddDays(6),
                     35.121,
                     49.121,
                     field2));
            return sensorList;
        }
    }
}