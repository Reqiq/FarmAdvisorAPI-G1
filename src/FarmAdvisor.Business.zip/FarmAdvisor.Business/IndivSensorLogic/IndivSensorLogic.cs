﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FarmAdvisor.Business.IndivSensorLogic
{
    public class IndivSensorLogic
    {
        public WeatherForecastApi _weatherForecastApi;

        public IndivSensorLogic(WeatherForecastApi weatherForecastApi)
        {
            _weatherForecastApi = weatherForecastApi;
        }

        public async Task Run(Sensor sensor)
        {
            await _weatherForecastApi.GetLocationForecast(sensor.Lat, sensor.Long, sensor.Field.Alt);
        }
    }
}
