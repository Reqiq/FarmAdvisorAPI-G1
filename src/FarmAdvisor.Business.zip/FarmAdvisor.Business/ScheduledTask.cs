﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace FarmAdvisor.Business
{
    public class ScheduledTask
    {
        public static void Run()
        {
            var sensorList = SensorImitation.GetActiveSensors();
            foreach(var sensor in sensorList)
            {
                
            }
        }
    }
}
